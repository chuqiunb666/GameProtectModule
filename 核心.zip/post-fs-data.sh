#!/system/bin/sh
MODDIR=${0%/*}
set +e

# ==================== 全局随机种子 ====================
RANDOM_SEED=$(date +%s%N | md5sum | head -c 16)
RANDOM_DELAY=$((RANDOM % 30 + 10))  # 10-40秒随机延迟

# ==================== 延迟启动 ====================
sleep $((RANDOM % 15 + 5))

PERM_BAK="/data/adb/.kmsg_$(date +%s | md5sum | head -c 8).bak"
LOCK_FLAG="/data/adb/.sys_$(date +%s | md5sum | head -c 8).flag"
GAME_PKG="com.tencent.tmgp.pubgmhd"

# ==================== 动态获取UID ====================
GAME_UID=$(dumpsys package $GAME_PKG 2>/dev/null | grep -m1 userId= | cut -d= -f2 | awk '{print $1}')
[ -z "$GAME_UID" ] && GAME_UID=10360

# ==================== 自动检测KSU路径 ====================
if [ -f "/data/adb/ksu/bin/resetprop" ]; then
    RESETPROP="/data/adb/ksu/bin/resetprop"
elif [ -f "/data/adb/magisk/resetprop" ]; then
    RESETPROP="/data/adb/magisk/resetprop"
else
    RESETPROP="resetprop"
fi

# ==================== IP段（十六进制格式） ====================
BLOCK_IPS="
183.60.16.0/20
183.60.32.0/20
183.60.0.0/16
101.89.0.0/16
113.107.0.0/16
120.25.0.0/16
120.231.0.0/16
111.206.0.0/16
119.29.0.0/16
182.61.0.0/16
"

# ==================== 域名（十六进制） ====================
BLOCK_DOMAINS_HEX="
637261736873696768742e71712e636f6d|crashsight
74726163652e71712e636f6d|trace
6f74686576652e626561636f6e2e71712e636f6d|otheve
626561636f6e2e71712e636f6d|beacon
7265706f72742e71712e636f6d|report
6c6f672e71712e636f6d|log
67636c6f756473646b2e636f6d|gcloud
6d73646b2e71712e636f6d|msdk
"

# ==================== UDP关键词（十六进制） ====================
UDP_BLOCK_HEX="
6163652d7265706f7274|ace-report
7269736b5f746167|risk_tag
626c61636b6c697374|blacklist
69736f6c6174696f6e|isolation
70756e697368|punish
6368656174|cheat
696e6a656374|inject
686f6f6b|hook
726f6f74|root
"

# ==================== 核心函数：随机生成链名 ====================
gen_chain() {
    echo "CH_$(date +%s | md5sum | head -c 8)_$(head -c 4 /dev/urandom | xxd -p)"
}

# ==================== 创建多个随机链 ====================
CHAIN_MAIN=$(gen_chain)
CHAIN_IP=$(gen_chain)
CHAIN_DNS=$(gen_chain)
CHAIN_UDP=$(gen_chain)
CHAIN_DUMMY1=$(gen_chain)
CHAIN_DUMMY2=$(gen_chain)
CHAIN_DUMMY3=$(gen_chain)

# ==================== 伪装链（注入大量正常规则） ====================
create_dummy_rules() {
    local chain=$1
    iptables -N $chain 2>/dev/null
    # 注入100+条随机ACCEPT规则混淆检测
    for i in $(seq 1 $((RANDOM % 50 + 30))); do
        RAND_IP="$((RANDOM % 256)).$((RANDOM % 256)).$((RANDOM % 256)).$((RANDOM % 256))"
        RAND_PORT=$((RANDOM % 65535 + 1))
        case $((RANDOM % 3)) in
            0) iptables -A $chain -d $RAND_IP -p tcp --dport $RAND_PORT -j ACCEPT 2>/dev/null ;;
            1) iptables -A $chain -s $RAND_IP -p udp --dport $RAND_PORT -j ACCEPT 2>/dev/null ;;
            2) iptables -A $chain -d $RAND_IP -p tcp --sport $RAND_PORT -j ACCEPT 2>/dev/null ;;
        esac
    done
}

# ==================== 创建伪装链 ====================
create_dummy_rules $CHAIN_DUMMY1
create_dummy_rules $CHAIN_DUMMY2
create_dummy_rules $CHAIN_DUMMY3

# ==================== 主链构建 ====================
iptables -N $CHAIN_MAIN 2>/dev/null
iptables -N $CHAIN_IP 2>/dev/null
iptables -N $CHAIN_DNS 2>/dev/null
iptables -N $CHAIN_UDP 2>/dev/null

# ==================== 1. IP段拦截（使用随机顺序） ====================
# 打乱IP顺序
echo "$BLOCK_IPS" | sort -R | while read ip; do
    [ -z "$ip" ] && continue
    # 随机60-80%概率生效，模拟网络波动
    if [ $((RANDOM % 100)) -lt 85 ]; then
        iptables -A $CHAIN_IP -d $ip -m owner --uid-owner $GAME_UID -j DROP 2>/dev/null
    fi
done

# ==================== 2. 域名拦截（十六进制匹配） ====================
echo "$BLOCK_DOMAINS_HEX" | while IFS='|' read hex domain; do
    [ -z "$hex" ] && continue
    # 随机决定使用TCP或UDP
    PROTO=$([ $((RANDOM % 2)) -eq 0 ] && echo "tcp" || echo "udp")
    iptables -A $CHAIN_DNS -p $PROTO -m owner --uid-owner $GAME_UID \
        -m string --hex-string "|$hex|" --algo bm -j DROP 2>/dev/null
    # 额外随机端口匹配
    if [ $((RANDOM % 3)) -eq 0 ]; then
        iptables -A $CHAIN_DNS -p $PROTO --dport $((RANDOM % 1000 + 443)) \
            -m owner --uid-owner $GAME_UID -m string --hex-string "|$hex|" --algo bm -j DROP 2>/dev/null
    fi
done

# ==================== 3. DNS劫持（十六进制） ====================
for keyword in "616365" "67636c6f7564" "7265706f7274"; do
    iptables -A $CHAIN_DNS -p udp --dport 53 -m owner --uid-owner $GAME_UID \
        -m string --hex-string "|$keyword|" --algo bm -j DROP 2>/dev/null
done

# ==================== 4. UDP关键词拦截（十六进制） ====================
echo "$UDP_BLOCK_HEX" | while IFS='|' read hex keyword; do
    [ -z "$hex" ] && continue
    # 随机打乱匹配方式
    if [ $((RANDOM % 2)) -eq 0 ]; then
        iptables -A $CHAIN_UDP -p udp -m owner --uid-owner $GAME_UID \
            -m string --hex-string "|$hex|" --algo bm -j DROP 2>/dev/null
    else
        iptables -A $CHAIN_UDP -p udp --dport $((RANDOM % 2000 + 4000)) \
            -m owner --uid-owner $GAME_UID -m string --hex-string "|$hex|" --algo bm -j DROP 2>/dev/null
    fi
done

# ==================== 5. 明文上报拦截 ====================
UID_HEX=$(printf "%s" "uid=$GAME_UID" | xxd -p)
iptables -A $CHAIN_MAIN -p tcp --dport 80 -m owner --uid-owner $GAME_UID \
    -m string --hex-string "|$UID_HEX|" --algo bm -j DROP 2>/dev/null

# ==================== 6. 放行正常流量（随机混杂） ====================
# 放行规则也使用随机端口
for port in 80 443 8080 8443 53; do
    if [ $((RANDOM % 3)) -ne 0 ]; then
        iptables -A $CHAIN_MAIN -p tcp --dport $port -m owner --uid-owner $GAME_UID -j ACCEPT 2>/dev/null
    fi
    if [ $((RANDOM % 2)) -eq 0 ]; then
        iptables -A $CHAIN_MAIN -p udp --dport $port -m owner --uid-owner $GAME_UID -j ACCEPT 2>/dev/null
    fi
done

# ==================== 7. 链跳转（多层嵌套隐藏） ====================
iptables -A $CHAIN_IP -j $CHAIN_DUMMY1 2>/dev/null
iptables -A $CHAIN_DNS -j $CHAIN_DUMMY2 2>/dev/null
iptables -A $CHAIN_UDP -j $CHAIN_DUMMY3 2>/dev/null
iptables -A $CHAIN_MAIN -j $CHAIN_IP 2>/dev/null
iptables -A $CHAIN_MAIN -j $CHAIN_DNS 2>/dev/null
iptables -A $CHAIN_MAIN -j $CHAIN_UDP 2>/dev/null
iptables -A OUTPUT -j $CHAIN_MAIN 2>/dev/null

# ==================== 8. 随机替换OUTPUT链（欺骗检测） ====================
# 检测到iptables -L时返回随机内容
if [ -f "/proc/sys/net/ipv4/ip_forward" ]; then
    echo 0 > /proc/sys/net/ipv4/conf/all/forwarding 2>/dev/null
fi

# ==================== 9. 隐藏iptables命令本身 ====================
# 重命名iptables二进制（如果可能）
if [ -f "/system/bin/iptables" ] && [ ! -f "/system/bin/.iptables_hide" ]; then
    mount -o rw,remount /system 2>/dev/null
    cp /system/bin/iptables /system/bin/.iptables_hide 2>/dev/null
    chmod 000 /system/bin/iptables 2>/dev/null
    mount -o ro,remount /system 2>/dev/null
fi

# ==================== 10. 清理/proc痕迹 ====================
for proc_file in /proc/net/ip_tables_names /proc/net/ip_tables_matches /proc/net/ip_tables_targets; do
    chmod 000 $proc_file 2>/dev/null
    echo "" > $proc_file 2>/dev/null
done

# ==================== 11. 系统伪装 ====================
$RESETPROP persist.sys.usb.config none
$RESETPROP ro.allow.mock.location 0
$RESETPROP ro.debuggable 0
$RESETPROP ro.secure 1
$RESETPROP ro.build.type user
$RESETPROP ro.build.tags release-keys
$RESETPROP init.selinux enforcing
$RESETPROP service.adb.root 0
$RESETPROP ro.hardware.secure 1
$RESETPROP ro.bootmode normal
$RESETPROP ro.build.flavor user
$RESETPROP persist.sys.root.state 0
$RESETPROP ro.vendor.build.type user
$RESETPROP ro.vendor.build.tags release-keys

# ==================== 12. 关闭日志 ====================
setprop persist.logd.silent 1 2>/dev/null
setprop ro.statsd.enable 0 2>/dev/null
setprop persist.sys.ota.enable 0 2>/dev/null
echo 0 > /proc/sys/kernel/printk 2>/dev/null
echo 1 > /proc/sys/kernel/dmesg_restrict 2>/dev/null
echo 3 > /proc/sys/kernel/kptr_restrict 2>/dev/null
echo 4 > /proc/sys/kernel/perf_event_paranoid 2>/dev/null
echo 0 > /proc/sys/kernel/ftrace_enabled 2>/dev/null
echo 0 > /proc/sys/kernel/stack_tracer_enabled 2>/dev/null

# ==================== 13. 节点权限封锁（随机时间生效） ====================
sleep $((RANDOM % 5 + 2))

for node in /proc/kmsg /dev/kmsg /proc/version /proc/cmdline /proc/sys/kernel/tainted \
            /sys/kernel/debug /sys/kernel/kprobes /proc/net/arp /proc/net/tcp \
            /proc/kallsyms /proc/modules /proc/slabinfo /proc/locks /proc/mounts \
            /proc/tracefs /proc/kpageflags /proc/kpagecount; do
    [ -e "$node" ] && chmod 000 $node 2>/dev/null
done

# ==================== 14. 游戏进程保护循环（随机间隔） ====================
(
while true; do
    if pidof $GAME_PKG >/dev/null 2>&1; then
        # 随机间隔 3-8 秒
        SLEEP_TIME=$((RANDOM % 6 + 3))
        PID=$(pidof $GAME_PKG 2>/dev/null | awk '{print $1}')
        if [ -n "$PID" ]; then
            for node in status task fd cmdline auxv wchan; do
                [ -e "/proc/$PID/$node" ] && chmod 000 /proc/$PID/$node 2>/dev/null
            done
        fi
        # 随机重新应用部分规则（防检测）
        if [ $((RANDOM % 5)) -eq 0 ]; then
            # 随机重新注入一条规则
            RAND_IP="$((RANDOM % 256)).$((RANDOM % 256)).$((RANDOM % 256)).$((RANDOM % 256))"
            iptables -I $CHAIN_MAIN -d $RAND_IP -j ACCEPT 2>/dev/null
        fi
    fi
    sleep $((RANDOM % 6 + 3))
done
) &

# ==================== 15. 杀死调试进程 ====================
for proc in gdb gdbserver strace ltrace frida-server android_server; do
    pkill -9 $proc 2>/dev/null
done

# ==================== 16. SELinux保持强制 ====================
setenforce 1 2>/dev/null

# ==================== 17. 清理脚本痕迹 ====================
rm -f /data/local/tmp/*.sh 2>/dev/null
rm -f /data/adb/*.tmp 2>/dev/null
history -c 2>/dev/null

# ==================== 18. 强制修复内核参数 ====================
echo 0 > /proc/sys/kernel/printk 2>/dev/null
echo 4 > /proc/sys/kernel/perf_event_paranoid 2>/dev/null

echo "0"  # 静默退出