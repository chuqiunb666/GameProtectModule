#!/system/bin/sh
MODDIR=${0%/*}

ui_print "正在配置模块权限..."
# 给 post-fs-data.sh 加上执行权限，这是关键！
[ -f "$MODPATH/post-fs-data.sh" ] && chmod 0755 "$MODPATH/post-fs-data.sh" 2>/dev/null
ui_print "模块部署完成，重启设备生效"

exit 0
